#ifndef __RDA_REGS_H
#define __RDA_REGS_H

#include <stdint.h>

// REG02
typedef union {
    uint16_t raw;
    struct {
        uint16_t ENABLE        : 1;
        uint16_t MUTE          : 1;
        uint16_t MONO          : 1;
        uint16_t BASS          : 1;
        uint16_t SEEKUP        : 1;
        uint16_t SEEK          : 1;
        uint16_t RDS_EN        : 1; // düzeltildi
        uint16_t NEW_METHOD    : 1;
        uint16_t SOFT_RESET    : 1;
        uint16_t RCLK_DIRECT_IN: 1;
        uint16_t CLK_MODE      : 3;
        uint16_t SKMODE        : 1;
        uint16_t DMUTE         : 1; // eklendi
        uint16_t DHIZ          : 1;
    } refined;
} RDA_Reg02;

// REG03
typedef union {
    uint16_t raw;
    struct {
        uint16_t CHAN        : 10;
        uint16_t DIRECT_MODE : 1;
        uint16_t SPACE       : 2;
        uint16_t BAND        : 2;
        uint16_t TUNE        : 1;
    } refined;
} RDA_Reg03;

// REG04
typedef union {
    uint16_t raw;
    struct {
        uint16_t DE            : 1;
        uint16_t SOFTMUTE_EN   : 1;
        uint16_t AFCD          : 1;
        uint16_t RBDS          : 1;
        uint16_t STCIEN        : 1;
        uint16_t RDS_FIFO_CLR  : 1;
        uint16_t RDS_FIFO_EN   : 1;
        uint16_t RBDS_EN       : 1;
        uint16_t : 8;
    } refined;
} RDA_Reg04;

// REG05
typedef union {
    uint16_t raw;
    struct {
        uint16_t VOLUME        : 4;
        uint16_t SEEKTH        : 4;
        uint16_t LNA_ICSEL_BIT : 2; // düzeltildi
        uint16_t LNA_PORT_SEL  : 2;
        uint16_t INT_MODE      : 1;
        uint16_t : 3;
    } refined;
} RDA_Reg05;

// REG0A
typedef union {
    uint16_t raw;
    struct {
        uint16_t READCHAN : 10;
        uint16_t STC      : 1;
        uint16_t SF       : 1;
        uint16_t RDSS     : 1;
        uint16_t ST       : 1;
        uint16_t BLK_E    : 2;
        uint16_t RDSR     : 1; // BU OLMALI
    } refined;
} RDA_Reg0A;

// REG0B
typedef union {
    uint16_t raw;
    struct {
        uint16_t RSSI     : 6;
        uint16_t : 2;
        uint16_t FM_TRUE  : 1; // eklendi
        uint16_t BLERB    : 2;
        uint16_t : 5;
        uint8_t ABCD_E : 1;   // BU SATIR OLMALI
    } refined;
} RDA_Reg0B;

// REG0C, REG0D, REG0E, REG0F — eğer kullanılmıyorsa sade tanım
typedef union {
    uint16_t raw;
    struct {
        uint16_t bits;
    } refined;
} RDA_Reg0C, RDA_Reg0D, RDA_Reg0E, RDA_Reg0F;

#endif // __RDA_REGS_H
