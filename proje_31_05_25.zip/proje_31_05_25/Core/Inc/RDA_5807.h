#ifndef __RDA_5807_H
#define __RDA_5807_H

#ifdef __cplusplus
 extern "C" {
#endif


#include "stm32l0xx_hal.h"
#include "stm32l0xx_hal_conf.h"
#include "RDA_legs.h"
#include "stm32l0xx_hal_i2c.h"
#include "main.h"



 // === Struct Tanımı ===
 typedef struct {
   uint8_t currentFMBand;
   uint8_t currentFMSpace;
   uint16_t currentFrequency;
   uint8_t currentVolume;

   RDA_Reg02 reg02;
   RDA_Reg03 reg03;
   RDA_Reg04 reg04;
   RDA_Reg05 reg05;
   RDA_Reg0A reg0A;
   RDA_Reg0B reg0B;
   RDA_Reg0C reg0C;
   RDA_Reg0D reg0D;
   RDA_Reg0E reg0E;
   RDA_Reg0F reg0F;
 } RDA_Handle;

 extern RDA_Handle handle;

typedef enum
{
    FALSE,
    TRUE,
    MAX
} BOOL;

#define MAX_DELAY_AFTER_OSCILLATOR 500  // Max delay after the crystal oscilator becomes active

#define I2C_ADDR_DIRECT_ACCESS  0x11    //!< Can be used to access a given register at a time.
#define I2C_ADDR_FULL_ACCESS    0x10    //!< Can be used to access a set of register at a time.

#define OSCILLATOR_TYPE_CRYSTAL  0  //!< Crystal
#define OSCILLATOR_TYPE_REFCLK   1  //!< Reference clock

#define CLOCK_32K                0  //!< 32.768kHz
#define CLOCK_12M                1  //!< 12Mhz
#define CLOCK_13M                2  //!< 13Mhz
#define CLOCK_19_2M              3  //!< 19.2Mhz
#define CLOCK_24M                5  //!< 24Mhz 
#define CLOCK_26M                6  //!< 26Mhz 
#define CLOCK_38_4M              7  //!< 38.4Mhz 

#define RDS_STANDARD     0  //!< RDS Mode.
#define RDS_VERBOSE      1  //!< RDS Mode.

#define RDA_FM_BAND_USA_EU       0  //!< 87.5–108 MHz (US / Europe, Default)
#define RDA_FM_BAND_JAPAN_WIDE   1  //!< 76–91 MHz (Japan wide band)
#define RDA_FM_BAND_WORLD        2  //!< 76–108 MHz (world wide)
#define RDA_FM_BAND_SPECIAL      3  //!< 65 –76 MHz(East Europe) or 50 - 65MHz(see bit 9 of register 0x06)

#define RDA_SEEK_WRAP  0     //!< Wrap at the upper or lower band limit and continue seeking
#define RDA_SEEK_STOP  1     //!< Stop seeking at the upper or lower band limit
#define RDA_SEEK_DOWN  0     //!< Seek Up
#define RDA_SEEK_UP    1     //!< Seek Down

#define REG00 0x00
#define REG02 0x02
#define REG03 0x03
#define REG04 0x04
#define REG05 0x05
#define REG06 0x06
#define REG07 0x07
#define REG0A 0x0A
#define REG0B 0x0B
#define REG0C 0x0C
#define REG0D 0x0D
#define REG0E 0x0E
#define REG0F 0x0F

#define SH_REG0A 0 // Shadow array position for register 0x0A
#define SH_REG0B 1 // Shadow array position for register 0x0B
#define SH_REG0C 2 // Shadow array position for register 0x0C - RDS Block A
#define SH_REG0D 3 // Shadow array position for register 0x0D - RDS Block B
#define SH_REG0E 4 // Shadow array position for register 0x0E - RDS Block C
#define SH_REG0F 5 // Shadow array position for register 0x0F - RDS Block D

/**
 * @defgroup GA01 Union, Structure and Defined Data Types
 * @brief   rda Defined Data Types
 * @details Defined Data Types is a way to represent the rda registers information
 * @details The information shown here was extracted from Datasheet:
 * @details rda stereo FM digital tuning radio documentation.
 */

/**
 * @ingroup GA01
 * @brief Register 0x00
 *
 */
    typedef union {
    struct {
        uint8_t CHIPID: 8; //!< Chip ifdef 
        uint8_t DUMMY: 8;
    } refined;
    uint16_t raw;
} RDA_Reg00;

/**
 * @ingroup GA01
 * @brief Register 0x01 - Dummy
 * @details It is not documented by the RDA. 
 */
typedef union
{
    struct
    {
        uint8_t lowByte; 
        uint8_t highByte;
    } refined;
    uint16_t raw;
} RDA_Reg01;


/**
 * @ingroup GA01
 * @brief Register 0x04
 * @details Receiver properties 
 * @details Volume scale is logarithmic When 0000, output mute and output impedance is very large
 * @details Setting STCIEN = 1 will generate a low pulse on GPIO2 when the interrupt occurs.
 */

typedef union {
    struct
    {
        uint8_t R_DELY : 1;       //!< If 1, R channel data delay 1T.
        uint8_t L_DELY : 1;       //!< If 1, L channel data delay 1T.
        uint8_t SCLK_O_EDGE : 1;  //!< If 1, invert sclk output when as master.
        uint8_t SW_O_EDGE : 1;    //!< If 1, invert ws output when as master.
        uint8_t I2S_SW_CNT : 4;   //!< Only valid in master mode. See table above
        uint8_t WS_I_EDGE : 1;    //!< If 0, use normal ws internally; If 1, inverte ws internally.
        uint8_t DATA_SIGNED : 1;  //!< If 0, I2S output unsigned 16-bit audio data. If 1, I2S output signed 16-bit audio data.
        uint8_t SCLK_I_EDGE : 1;  //!< If 0, use normal sclk internally;If 1, inverte sclk internally.
        uint8_t WS_LR : 1;        //!< Ws relation to l/r channel; If 0, ws=0 ->r, ws=1 ->l; If 1, ws=0 ->l, ws=1 ->r.
        uint8_t SLAVE_MASTER : 1; //!< I2S slave or master; 1 = slave; 0 = master.
        uint8_t OPEN_MODE : 2;    //!< Open reserved register mode;  11=open behind registers writing function others: only open behind registers reading function.
        uint8_t RSVD : 1;
    } refined;
    uint16_t raw;
} RDA_Reg06;

/**
 * @ingroup GA01
 * @brief Register 0x07
 */
typedef union {
    struct
    {
        uint8_t FREQ_MODE : 1;    //!< If 1, then freq setting changed. Freq = 76000(or 87000) kHz + freq_direct (08H) kHz.
        uint8_t SOFTBLEND_EN : 1; //!< If 1, Softblend enable
        uint8_t SEEK_TH_OLD : 6;  //!< Seek threshold for old seek mode, Valid when Seek_Mode=001
        uint8_t RSVD1 : 1;
        uint8_t MODE_50_60 : 1;   //!< 1 = 65~76 MHz;  0 = 50~76MHz
        uint8_t TH_SOFRBLEND : 5; //!< Threshold for noise soft blend setting, unit 2dB (default 0b10000).
        uint8_t RSVD2 : 1;
    } refined;
    uint16_t raw;
} RDA_Reg07;

/**
 * @ingroup GA01
 * @brief Register 0x08 - Direct Frequency 
 * @details Valid when freq_mode = 1
 * @details Freq = 7600(or 8700) kHz + freq_direct (08H) kHz.
 * @details Value to be stores is frequency - 7600 or 8700
 */
typedef union
{
   struct
    {
      uint8_t lowByte;
      uint8_t highByte;   
    } refined;
    uint16_t raw;
} RDA_Reg08;

/**
 * @ingroup GA01
 * @brief Register 0x0A - Device current status
 * @details The seek fail flag (SF) is set when the seek operation fails to find a channel with an RSSI level greater than SEEKTH[5:0].
 * @details The seek/tune complete (STC) flag is set when the seek or tune operation completes.
 * 
 *  Channel table 
 * 
 * | BAND   | Description                                         | 
 * | ------ | --------------------------------------------------  | 
 * |  0     | Frequency = Channel Spacing (kHz) x CHAN+ 87.0 MHz  |
 * | 1 or 2 | Frequency = Channel Spacing (kHz) x CHAN + 76.0 MHz | 
 * | 3      | Frequency = Channel Spacing (kHz) x CHAN + 65.0 MHz | 
 */

/**
 * @ingroup RDA_API
 * @brief Init the RDA chip
 * @param  I2C Port
 */
void RDA_Init( );
void getStatus(uint8_t reg);

/**
 * @ingroup RDA_API
 * @brief De-Init the RDA chip
 * @param  I2C Port
 */
void RDA_DeInit( );

/**
 * @ingroup RDA_API
 * @brief Soft reset the RDA chip
 * @param  I2C Port
 */
void RDA_SoftReset( );

/**
 * @ingroup RDA_API
 * @brief Set frequency on RDA chip
 * @param  I2C Port
 * @param frequency frequency
 */
void RDA_Tune( uint16_t frequency);

/**
 * @ingroup RDA_API
 * @brief Call manual seek down on RDA chip
 * @param  I2C Port
 */
void RDA_ManualDown( );

/**
 * @ingroup RDA_API
 * @brief Call manual seek up on RDA chip
 * @param  I2C Port
 */
void RDA_ManualUp( );

/**
 * @ingroup RDA_API
 * @brief Get real frequency on RDA chip
 * | Band   | Formula |
 * | ------ | ------- | 
 * |    0   | Frequency = Channel Spacing (kHz) x READCHAN[9:0]+ 87.0 MHz |
 * | 1 or 2 | Frequency = Channel Spacing (kHz) x READCHAN[9:0]+ 76.0 MHz |
 * |    3   | Frequency = Channel Spacing (kHz) x READCHAN[9:0]+ 65.0 MHz |
 * @param  I2C Port
 */
uint16_t RDA_GetRealFrequency( );

/**
 * @ingroup RDA_API
 * @brief Call seek on RDA chip
 * @param  I2C Port
 * @param seek_mode if 0, wrap at the upper or lower band limit and continue seeking; 1 = stop seeking at the upper or lower band limit
 * @param direction if 0, seek down; if 1, seek up.
 */
void RDA_Seek( uint8_t seek_mode, uint8_t direction);

/**
 * @ingroup RDA_API
 * @brief Set seek threshold on RDA chip
 * @param  I2C Port
 * @param value RSSI threshold
 */
void RDA_SetSeekThreshold( uint8_t value);

/**
 * @ingroup RDA_API
 * @brief Set FM band on RDA chip
 * @param  I2C Port
 * @param band FM band
 * | Value | Description                 |
 * | ----- | --------------------------- |
 * | 00    | 87–108 MHz (US/Europe)      |
 * | 01    | 76–91 MHz (Japan)           |
 * | 10    | 76–108 MHz (world wide)     |
 * | 11    | 65 –76 MHz (East Europe) or 50-65MHz (see bit 9 of gegister 0x06) |
 */
void RDA_SetBand( uint8_t band);

/**
 * @ingroup RDA_API
 * @brief Set FM space on RDA chip
 * @param  I2C Port
 * @param space FM space
 * | Value | Description |
 * | ----- | ----------- |
 * | 00    | 100KHz      |
 * | 01    | 200KHz      |
 * | 10    | 50KHz       |
 * | 11    | 25KHz       |
 */
void RDA_SetSpace( uint8_t space);

/**
 * @ingroup RDA_API
 * @brief Get the current RSSI
 * @param  I2C Port
 * @details RSSI - 000000(Min) 111111(Max) RSSI scale is logarithmic.
 * @return int32_t
 */
int32_t RDA_GetQuality( );

/**
 * @ingroup RDA_API
 * @brief Set FM soft mute on RDA chip
 * @param  I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetSoftMute( BOOL value);
// RDA_5807.h içine ekle:
void registerWrite(uint8_t reg, uint16_t value);


/**
 * @ingroup RDA_API
 * @brief Set FM mute on RDA chip
 * @param  I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetMute( BOOL value);

/**
 * @ingroup RDA_API
 * @brief Set mono on RDA chip
 * @param  I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetMono( BOOL value);

/**
 * @ingroup RDA_API
 * @brief Set bass on RDA chip
 * @param  I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetBass( BOOL value);

/**
 * @ingroup RDA_API
 * @brief Get mono status on RDA chip
 * @param  I2C Port
 * @return value TRUE/FALSE
 */
BOOL RDA_GetSterioStatus( );

/**
 * @ingroup RDA_API
 * @brief Set volume on RDA chip
 * @param  I2C Port
 * @param value 0-15 levels
 */
void RDA_SetVolume( uint8_t value);

/**
 * @ingroup RDA_API
 * @brief Get internal volume on RDA chip
 * @param  I2C Port
 * @return uint8_t 0-15 levels
 */
uint8_t RDA_GetVolume( );

/**
 * @ingroup RDA_API
 * @brief Call volume up on RDA chip
 * @param  I2C Port
 */
void RDA_SetVolumeUp( );

/**
 * @ingroup RDA_API
 * @brief Call volume down on RDA chip
 * @param  I2C Port
 */
void RDA_SetVolumeDown( );

/**
 * @ingroup RDA_API
 * @brief Set FM De-Emphasis on RDA chip
 * @param  I2C Port
 * @param deEmphasis deEmphasis
 */
void RDA_SetFMDeEmphasis( uint8_t deEmphasis);

/**
 * @ingroup RDA_API
 * @brief Set RDS on RDA chip
 * @param  I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetRDS( BOOL value);

/**
 * @ingroup RDA_API
 * @brief Set RBDS on RDA chip
 * @param  I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetRBDS( BOOL value);

/**
 * @ingroup RDA_API
 * @brief Get RDS Ready on RDA chip
 * @param  I2C Port
 * @return TRUE/FALSE
 */
BOOL RDA_GetRDSReady( );

/**
 * @ingroup RDA_API
 * @brief Get RDS Sync on RDA chip
 * @param  I2C Port
 * @return TRUE/FALSE
 */
BOOL RDA_GetRDSSync( );

/**
 * @ingroup RDA_API
 * @brief Get Block ID on RDA chip
 * @param  I2C Port
 * @return uint8_t
 */
uint8_t RDA_GetBlockId( );

/**
 * @ingroup RDA_API
 * @brief Set volume down on RDA chip
 * @param  I2C Port
 * @return uint8_t
 */
uint8_t RDA_GetErrorBlockB( );

/**
 * @ingroup RDA_API
 * @brief Get RDS info state on RDA chip
 * @param  I2C Port
 * @return TRUE/FALSE
 */
BOOL RDA_GetRDSInfoState( );

/**
 * @ingroup RDA_API
 * @brief Set RDS FIFO on RDA chip
 * @param  I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetRDSFifo( BOOL value);

/**
 * @ingroup RDA_API
 * @brief Call clear RDS FIFO on RDA chip
 * @param  I2C Port
 */
void RDA_ClearRDSFifo( );

#ifdef __cplusplus
}
#endif
extern RDA_Handle handle;

#endif /*__RDA_5807_H */

