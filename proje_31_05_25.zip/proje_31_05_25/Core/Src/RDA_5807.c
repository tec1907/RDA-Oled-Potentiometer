#include <RDA_5807.h>
#include <stdlib.h>
#include "stm32l0xx_hal.h"
#include "stm32l0xx_hal_i2c.h"

RDA_Handle handle;


extern I2C_HandleTypeDef hi2c1;


#define WRITE_DELAY 3
#define MIN_DELAY 1

const uint16_t startBand[4] = {8700, 7600, 7600, 6500};
const uint16_t endBand[4] = {10800, 9100, 10800, 7600};
const uint16_t fmSpace[4] = {100, 200, 50, 25};





#ifdef SYSTICK_DELAY
#define MS_CORE (SystemCoreClock / 1000)
__IO uint32_t systickValue = 0;

void Delay_Init()
{
	SystemCoreClockUpdate(); // Update SystemCoreClock variable
	SysTick_Config(MS_CORE); // 1 Milli second
}

uint32_t getMillis()
{
	return systickValue;
}

void Delay(uint32_t delay)
{
	uint32_t startMs = getMillis();
	while ((getMillis() - startMs) < delay);
}

/*
 * SysTick Interrupt Handler
 */
void SysTick_Handler()
{
	systickValue++;
}
#endif



/* This function transmits one byte to the slave device
 * Parameters:
 * I2Cx --- the I2C peripheral e.g.I2C1, I2C2
 * data --- the data byte to be transmitted
 */


/**
 * @ingroup GA03
 * @brief Gets the register content of a given status register (from 0x0A to 0x0F) 
 * @details Useful when you need just a specific status register content.
 * @details This method update the first element of the shadowStatusRegisters linked to the register
 * @return rdax_reg0a the reference to current value of the 0x0A register. 
 */
void getStatus(uint8_t reg)
{
    if (reg < 0x0A || reg > 0x0F) return;

    uint8_t regAddr = reg;
    uint8_t data[2];

    HAL_I2C_Master_Transmit(&hi2c1, I2C_ADDR_DIRECT_ACCESS << 1, &regAddr, 1, HAL_MAX_DELAY);
    HAL_I2C_Master_Receive(&hi2c1, I2C_ADDR_DIRECT_ACCESS << 1, data, 2, HAL_MAX_DELAY);

    uint16_t raw = (data[0] << 8) | data[1];

    switch (reg)
    {
        case REG0A: handle.reg0A = *(RDA_Reg0A *)&raw; break;
        case REG0B: handle.reg0B = *(RDA_Reg0B *)&raw; break;
        case REG0C: handle.reg0C = *(RDA_Reg0C *)&raw; break;
        case REG0D: handle.reg0D = *(RDA_Reg0D *)&raw; break;
        case REG0E: handle.reg0E = *(RDA_Reg0E *)&raw; break;
        case REG0F: handle.reg0F = *(RDA_Reg0F *)&raw; break;
        default: break;
    }
}
extern I2C_HandleTypeDef hi2c1;

void registerWrite(uint8_t reg, uint16_t value)
{
    uint8_t data[3];
    data[0] = reg;
    data[1] = (value >> 8) & 0xFF;
    data[2] = value & 0xFF;
    HAL_I2C_Master_Transmit(&hi2c1, I2C_ADDR_DIRECT_ACCESS << 1, data, 3, HAL_MAX_DELAY);
}
/**
 * @ingroup GA03
 * @brief Waits for Seek or Tune finish
 */
void waitAndFinishTune()
{
    int timeout = 100;
    do {
        getStatus(REG0A);
        HAL_Delay(5);
    } while (handle.reg0A.refined.STC == 0 && --timeout > 0);

    // STC 1 olduysa veya timeout bitti
    // STC’yi sıfırlamak için TUNE=0 yap
    handle.reg03.refined.TUNE = 0;
    registerWrite(REG03, handle.reg03.raw);
}

/**
 * @ingroup RDA_API
 * @brief Init the RDA chip
 * @param I2Cx I2C Port
 */
void RDA_Init()
{
#ifdef SYSTICK_DELAY
    Delay_Init();
    Delay(MIN_DELAY);
#endif
    handle.reg02.raw = 0x0;
    handle.reg02.refined.NEW_METHOD = 0;
    handle.reg02.refined.RDS_EN = 0; // RDS disable
    //handle.reg02.refined.CLK_MODE = CLOCK_32K;
    //handle.reg02.refined.RCLK_DIRECT_IN = OSCILLATOR_TYPE_CRYSTAL;
    handle.reg02.refined.CLK_MODE = CLOCK_12M;
    handle.reg02.refined.RCLK_DIRECT_IN = OSCILLATOR_TYPE_REFCLK;
    handle.reg02.refined.MONO = 1; // Force mono
    handle.reg02.refined.DMUTE = 1; // Normal operation
    handle.reg02.refined.DHIZ = 1; // Normal operation
    handle.reg02.refined.ENABLE = 1;
    handle.reg02.refined.BASS = 1;
    handle.reg02.refined.SEEK = 0;
    registerWrite(REG02, handle.reg02.raw);
    
    handle.reg05.raw = 0x0;
    handle.reg05.refined.INT_MODE = 0;
    handle.reg05.refined.LNA_PORT_SEL = 2;
    handle.reg05.refined.LNA_ICSEL_BIT = 0;
    handle.reg05.refined.SEEKTH = 8; // 0B1000
    handle.reg05.refined.VOLUME = 0;
    registerWrite(REG05, handle.reg05.raw);
}

/**
 * @ingroup RDA_API
 * @brief De-Init the RDA chip
 * @param I2Cx I2C Port
 */
void RDA_DeInit()
{
    handle.reg02.refined.SEEK = 0;
	handle.reg02.refined.ENABLE = 0;
    registerWrite(REG02, handle.reg02.raw);
}

/**
 * @ingroup RDA_API
 * @brief Soft reset the RDA chip
 * @param I2Cx I2C Port
 */
void RDA_SoftReset()
{
    handle.reg02.refined.SOFT_RESET = 1;
    registerWrite(REG02, handle.reg02.raw);
}

/**
 * @ingroup RDA_API (Internal)
 * @brief Set channel on RDA chip
 * @param I2Cx I2C Port
 * @param channel channel
 */
void RDA_SetChannel( uint16_t channel)
{
    handle.reg03.refined.CHAN = channel;
    handle.reg03.refined.TUNE = 1;
    handle.reg03.refined.BAND = 0;
    handle.reg03.refined.SPACE = 0;
    handle.reg03.refined.DIRECT_MODE = 0;
    registerWrite(REG03, handle.reg03.raw);
    waitAndFinishTune();
}

/**
 * @ingroup RDA_API
 * @brief Set frequency on RDA chip
 * @param I2Cx I2C Port
 * @param frequency frequency
 */
void RDA_Tune(uint16_t frequency)
{
    uint16_t channel = (frequency - startBand[handle.currentFMBand] ) / (fmSpace[handle.currentFMSpace] / 10.0);
    RDA_SetChannel( channel);
    handle.currentFrequency = frequency;
}

/**
 * @ingroup RDA_API
 * @brief Call manual seek down on RDA chi
 * @param I2Cx I2C Port
 */
void RDA_ManualDown()
{
    if (handle.currentFrequency < endBand[handle.currentFMBand])
    {
        handle.currentFrequency += (fmSpace[handle.currentFMSpace] / 10.0);
    }
    else
    {
        handle.currentFrequency = startBand[handle.currentFMBand];
    }
    RDA_Tune( handle.currentFrequency);
}

/**
 * @ingroup RDA_API
 * @brief Call manual seek up on RDA chip
 * @param I2Cx I2C Port
 */
void RDA_ManualUp()
{
    if (handle.currentFrequency > startBand[handle.currentFMBand])
    {
        handle.currentFrequency -= (fmSpace[handle.currentFMSpace] / 10.0);
    }
    else
    {
        handle.currentFrequency = endBand[handle.currentFMBand];
    }
    RDA_Tune( handle.currentFrequency);
}

/**
 * @ingroup RDA_API (Internal)
 * @brief Get real channel on RDA chip
 * @param I2Cx I2C Port
 */
uint16_t RDA_GetRealChannel()
{
    getStatus(REG0A);
    return handle.reg0A.refined.READCHAN;
}

/**
 * @ingroup RDA_API
 * @brief Get real frequency on RDA chip
 * | Band   | Formula |
 * | ------ | ------- | 
 * |    0   | Frequency = Channel Spacing (kHz) x READCHAN[9:0]+ 87.0 MHz |
 * | 1 or 2 | Frequency = Channel Spacing (kHz) x READCHAN[9:0]+ 76.0 MHz |
 * |    3   | Frequency = Channel Spacing (kHz) x READCHAN[9:0]+ 65.0 MHz |
 * @param I2Cx I2C Port
 */
uint16_t RDA_GetRealFrequency()
{
    return (RDA_GetRealChannel() * (fmSpace[handle.currentFMSpace] / 10.0) + startBand[handle.currentFMBand]);
}

/**
 * @ingroup RDA_API
 * @brief Call seek on RDA chip
 * @param I2Cx I2C Port
 * @param seek_mode if 0, wrap at the upper or lower band limit and continue seeking; 1 = stop seeking at the upper or lower band limit
 * @param direction if 0, seek down; if 1, seek up.
 */
void RDA_Seek( uint8_t seek_mode, uint8_t direction)
{
    handle.reg02.refined.SEEK = 1;
    handle.reg02.refined.SKMODE = seek_mode;
    handle.reg02.refined.SEEKUP = direction;
    registerWrite(REG02, handle.reg02.raw);
}

/**
 * @ingroup RDA_API
 * @brief Set seek threshold on RDA chip
 * @param I2Cx I2C Port
 * @param value RSSI threshold
 */
void RDA_SetSeekThreshold( uint8_t value)
{
    handle.reg05.refined.SEEKTH = value;
    registerWrite(REG05, handle.reg05.raw);
}

/**
 * @ingroup RDA_API
 * @brief Set FM band on RDA chip
 * @param I2Cx I2C Port
 * @param band FM band
 * | Value | Description                 |
 * | ----- | --------------------------- |
 * | 00    | 87–108 MHz (US/Europe)      |
 * | 01    | 76–91 MHz (Japan)           |
 * | 10    | 76–108 MHz (world wide)     |
 * | 11    | 65 –76 MHz (East Europe) or 50-65MHz (see bit 9 of gegister 0x06) |
 */
void RDA_SetBand( uint8_t band)
{
    handle.reg03.refined.BAND = band;
    registerWrite(REG03, handle.reg03.raw);
}

/**
 * @ingroup RDA_API
 * @brief Set FM space on RDA chip
 * @param I2Cx I2C Port
 * @param space FM space
 * | Value | Description |
 * | ----- | ----------- |
 * | 00    | 100KHz      |
 * | 01    | 200KHz      |
 * | 10    | 50KHz       |
 * | 11    | 25KHz       |
 */
void RDA_SetSpace(uint8_t space)
{
    handle.reg03.refined.SPACE = space;
    registerWrite(REG03, handle.reg03.raw);
}

/**
 * @ingroup RDA_API
 * @brief Get the current RSSI
 * @param I2Cx I2C Port
 * @details RSSI - 000000(Min) 111111(Max) RSSI scale is logarithmic.
 * @return int32_t
 */
int32_t RDA_GetQuality()
{
    getStatus(REG0B);
    return handle.reg0B.refined.RSSI;
}

/**
 * @ingroup RDA_API
 * @brief Set FM soft mute on RDA chip
 * @param I2Cx I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetSoftMute(BOOL value)
{
    handle.reg04.refined.SOFTMUTE_EN = value;
    registerWrite( REG04, handle.reg04.raw);
}

/**
 * @ingroup RDA_API
 * @brief Set FM mute on RDA chip
 * @param I2Cx I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetMute( BOOL value)
{
    handle.reg02.refined.SEEK = 0;    
    handle.reg02.refined.DHIZ = !value;
    registerWrite(REG02, handle.reg02.raw);
}

/**
 * @ingroup RDA_API
 * @brief Set mono on RDA chip
 * @param I2Cx I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetMono(BOOL value)
{
    handle.reg02.refined.SEEK = 0;
    handle.reg02.refined.MONO = value;
    registerWrite(REG02, handle.reg02.raw);
}

/**
 * @ingroup RDA_API
 * @brief Set bass on RDA chip
 * @param I2Cx I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetBass( BOOL value)
{
    handle.reg02.refined.SEEK = 0;
    handle.reg02.refined.BASS = value;
    registerWrite(REG02, handle.reg02.raw);
}

/**
 * @ingroup RDA_API
 * @brief Get mono status on RDA chip
 * @param I2Cx I2C Port
 * @return value TRUE/FALSE
 */
BOOL RDA_GetSterioStatus()
{
    getStatus(REG0A);
    return handle.reg0A.refined.ST;
}

/**
 * @ingroup RDA_API
 * @brief Set volume on RDA chip
 * @param I2Cx I2C Port
 * @param value 0-15 levels
 */
void RDA_SetVolume( uint8_t value)
{
    value > 15 ? value = 15 : value;
    handle.reg05.refined.VOLUME = handle.currentVolume = value;
    registerWrite( REG05, handle.reg05.raw);
}

/**
 * @ingroup RDA_API
 * @brief Get internal volume on RDA chip
 * @param I2Cx I2C Port
 * @return uint8_t 0-15 levels
 */
uint8_t RDA_GetVolume()
{
    return(handle.currentVolume);
}

/**
 * @ingroup RDA_API
 * @brief Call volume up on RDA chip
 * @param I2Cx I2C Port
 */
void RDA_SetVolumeUp()
{
    if (handle.currentVolume < 15)
    {
        handle.currentVolume++;
        RDA_SetVolume( handle.currentVolume);
    }
}

/**
 * @ingroup RDA_API
 * @brief Call volume down on RDA chip
 * @param I2Cx I2C Port
 */
void RDA_SetVolumeDown()
{
    if (handle.currentVolume > 0)
    {
        handle.currentVolume--;
        RDA_SetVolume( handle.currentVolume);
    }
}

/**
 * @ingroup RDA_API
 * @brief Set FM De-Emphasis on RDA chip
 * @param I2Cx I2C Port
 * @param deEmphasis deEmphasis
 */
void RDA_SetFMDeEmphasis( uint8_t deEmphasis)
{
    handle.reg04.refined.DE = deEmphasis;
    registerWrite(REG04, handle.reg04.raw);
}

/**
 * @ingroup RDA_API
 * @brief Set RDS on RDA chip
 * @param I2Cx I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetRDS( BOOL value)
{
    handle.reg02.refined.SEEK = 0;
    handle.reg02.refined.RDS_EN = value;
    registerWrite(REG02, handle.reg02.raw);
}

/**
 * @ingroup RDA_API
 * @brief Set RBDS on RDA chip
 * @param I2Cx I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetRBDS( BOOL value)
{
    handle.reg02.refined.SEEK = 0;
    handle.reg02.refined.RDS_EN = 1;
    registerWrite(REG02, handle.reg02.raw);

    handle.reg04.refined.RBDS = value;
    registerWrite(REG04, handle.reg04.raw);
}

/**
 * @ingroup RDA_API
 * @brief Get RDS Ready on RDA chip
 * @param I2Cx I2C Port
 * @return TRUE/FALSE
 */
BOOL RDA_GetRDSReady()
{
    getStatus(REG0A);
    return(handle.reg0A.refined.RDSR);
}

/**
 * @ingroup RDA_API
 * @brief Get RDS Sync on RDA chip
 * @param I2Cx I2C Port
 * @return TRUE/FALSE
 */
BOOL RDA_GetRDSSync()
{
    getStatus(REG0A);
    return handle.reg0A.refined.RDSS;
}

/**
 * @ingroup RDA_API
 * @brief Get Block ID on RDA chip
 * @param I2Cx I2C Port
 * @return uint8_t
 */
uint8_t RDA_GetBlockId()
{
    getStatus(REG0B);
    return handle.reg0B.refined.ABCD_E;
}

/**
 * @ingroup RDA_API
 * @brief Set volume down on RDA chip
 * @param I2Cx I2C Port
 * @return uint8_t
 */
uint8_t RDA_GetErrorBlockB()
{
    getStatus(REG0B);
    return handle.reg0B.refined.BLERB;
}

/**
 * @ingroup RDA_API
 * @brief Get RDS info state on RDA chip
 * @param I2Cx I2C Port
 * @return TRUE/FALSE
 */
BOOL RDA_GetRDSInfoState()
{
    getStatus(REG0B);
    return(handle.reg0A.refined.RDSS && handle.reg0B.refined.ABCD_E == 0 && handle.reg0B.refined.BLERB == 0);
}

/**
 * @ingroup RDA_API
 * @brief Set RDS FIFO on RDA chip
 * @param I2Cx I2C Port
 * @param value TRUE/FALSE
 */
void RDA_SetRDSFifo(BOOL value)
{
    handle.reg04.refined.RDS_FIFO_EN = value;
    registerWrite(REG04, handle.reg04.raw);
}

/**
 * @ingroup RDA_API
 * @brief Call clear RDS FIFO on RDA chip
 * @param I2Cx I2C Port
 */
void RDA_ClearRDSFifo()
{
    handle.reg04.refined.RDS_FIFO_CLR = 1;
    registerWrite(REG04, handle.reg04.raw);
}
