/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32l0xx_hal.h"
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include "RDA_5807.h"
#include <stdio.h>



/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
extern ADC_HandleTypeDef hadc;       // ADC1
extern UART_HandleTypeDef huart2;    // USART2
extern RDA_Handle_t handle;

I2C_HandleTypeDef hi2c1;
extern ADC_HandleTypeDef hadc;  // Eğer Cube'da adı hadc1 ise hadc1 yaz


/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_ADC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void ScanFrequenciesAndDisplay()
{
    uint16_t freqs[] = {890, 908, 920, 947, 954, 972, 984, 1000, 1040, 1074};
    char line1[32];
    char line2[32];

    for (int i = 0; i < sizeof(freqs)/sizeof(freqs[0]); i++) {
        RDA_Tune(freqs[i]);
        HAL_Delay(500); // sinyali alması için süre

        int rssi = RDA_GetQuality();

        sprintf(line1, "Frekans: %d.%d MHz", freqs[i]/10, freqs[i]%10);
        sprintf(line2, "RSSI: %d", rssi);

        ssd1306_Fill(Black);
        ssd1306_SetCursor(2, 0);
        ssd1306_WriteString(line1, Font_7x10, White);
        ssd1306_SetCursor(2, 16);
        ssd1306_WriteString(line2, Font_7x10, White);
        ssd1306_UpdateScreen();

        HAL_Delay(1500);
    }
}

void TestStrongestSignal()
{
    uint16_t freqs[] = {890, 908, 920, 947, 954, 972, 984, 1000, 1040, 1074};
    int strongestRSSI = -1;
    uint16_t bestFreq = 0;

    for (int i = 0; i < sizeof(freqs)/sizeof(freqs[0]); i++) {
        RDA_Tune(freqs[i]);
        HAL_Delay(500);  // sinyali bekle

        int rssi = RDA_GetQuality();

        if (rssi > strongestRSSI) {
            strongestRSSI = rssi;
            bestFreq = freqs[i];
        }
    }

    ssd1306_Fill(Black);
    ssd1306_SetCursor(0, 0);

    if (strongestRSSI < 30) {
        ssd1306_WriteString("Sinyal YOK", Font_7x10, White);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET); // LED sönük
    } else {
        char msg1[32];
        char msg2[32];
        sprintf(msg1, "Sinyal VAR!");
        sprintf(msg2, "%d.%d MHz RSSI:%d", bestFreq/10, bestFreq%10, strongestRSSI);
        ssd1306_WriteString(msg1, Font_7x10, White);
        ssd1306_SetCursor(0, 16);
        ssd1306_WriteString(msg2, Font_7x10, White);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET); // LED yanar
    }

    ssd1306_UpdateScreen();
}
void CycleFrequenciesForever()
{
    float freq = 89.0;

    while (1)
    {
        uint16_t freqRaw = (uint16_t)(freq * 10);  // RDA için çevir
        RDA_Tune(freqRaw);
        HAL_Delay(300);

        getStatus(REG0A);
        getStatus(REG0B);

        int rssi = RDA_GetQuality();
        uint8_t fm_true = handle.reg0B.refined.FM_TRUE;
        uint8_t stc = handle.reg0A.refined.STC;

        char line1[32];
        char line2[32];
        char line3[32];
        char line4[32];

        sprintf(line1, "Freq: %.1f MHz", freq);
        sprintf(line2, "RSSI: %d", rssi);
        sprintf(line3, "FM_TRUE: %d", fm_true);
        sprintf(line4, "STC: %d", stc);

        ssd1306_Fill(Black);
        ssd1306_SetCursor(0, 0); ssd1306_WriteString(line1, Font_7x10, White);
        ssd1306_SetCursor(0, 10); ssd1306_WriteString(line2, Font_7x10, White);
        ssd1306_SetCursor(0, 20); ssd1306_WriteString(line3, Font_7x10, White);
        ssd1306_SetCursor(0, 30); ssd1306_WriteString(line4, Font_7x10, White);
        ssd1306_UpdateScreen();

        HAL_Delay(500); // 0.5 saniye bekle

        freq += 0.2;
        if (freq > 107.0)
            freq = 89.0;
    }
}


void ScanAndTuneToStrongest()
{
    // Geniş frekans aralığı: 87.5 - 108.0 MHz arası
    uint16_t freqs[] = {
        875, 880, 885, 890, 895, 900, 905, 910,
        915, 920, 925, 930, 935, 940, 945, 950,
        955, 960, 965, 970, 975, 980, 985, 990,
        995, 1000, 1005, 1010, 1015, 1020, 1025,
        1030, 1035, 1040, 1045, 1050, 1055, 1060,
        1065, 1070, 1075, 1080
    };

    int strongestRSSI = -1;
    uint16_t bestFreq = 0;

    ssd1306_Fill(Black);
    ssd1306_SetCursor(0, 0);
    ssd1306_WriteString("TARAMA BASLIYOR", Font_7x10, White);
    ssd1306_UpdateScreen();
    HAL_Delay(1000);

    for (int i = 0; i < sizeof(freqs)/sizeof(freqs[0]); i++) {
        RDA_Tune(freqs[i]);
        HAL_Delay(400);
        int rssi = RDA_GetQuality();

        char line[32];
        sprintf(line, "%d.%d MHz RSSI:%d", freqs[i]/10, freqs[i]%10, rssi);
        ssd1306_Fill(Black);
        ssd1306_SetCursor(0, 0);
        ssd1306_WriteString(line, Font_7x10, White);
        ssd1306_UpdateScreen();

        if (rssi > strongestRSSI) {
            strongestRSSI = rssi;
            bestFreq = freqs[i];
        }

        HAL_Delay(600);
    }

    ssd1306_Fill(Black);
    ssd1306_SetCursor(0, 0);

    if (strongestRSSI > 20) {
        char msg1[32];
        char msg2[32];
        RDA_Tune(bestFreq);
        HAL_Delay(200);
        sprintf(msg1, "SINYAL VAR!");
        sprintf(msg2, "%d.%d MHz RSSI:%d", bestFreq/10, bestFreq%10, strongestRSSI);
        ssd1306_WriteString(msg1, Font_7x10, White);
        ssd1306_SetCursor(0, 16);
        ssd1306_WriteString(msg2, Font_7x10, White);
    } else {
        ssd1306_WriteString("SINYAL YOK!", Font_7x10, White);
    }

    ssd1306_UpdateScreen();
}
void test_rda5807_and_display(void)
{
    uint8_t reg = 0x0A;
    uint8_t buf[2] = {0};
    char line[32];

    HAL_StatusTypeDef status;

    // RDA5807 REG0A register'ına erişim
    status = HAL_I2C_Master_Transmit(&hi2c1, 0x11 << 1, &reg, 1, 100);
    if (status != HAL_OK) {
        ssd1306_Fill(Black);
        ssd1306_SetCursor(0, 0);
        ssd1306_WriteString("RDA5807 YOK!", Font_7x10, White);
        ssd1306_UpdateScreen();
        return;
    }

    // 2 byte veri okuma (REG0A)
    status = HAL_I2C_Master_Receive(&hi2c1, 0x11 << 1, buf, 2, 100);
    if (status == HAL_OK) {
        uint16_t reg0A = (buf[0] << 8) | buf[1];

        ssd1306_Fill(Black);
        ssd1306_SetCursor(0, 0);
        ssd1306_WriteString("RDA5807 BAGLANDI", Font_7x10, White);

        sprintf(line, "REG0A: 0x%04X", reg0A);
        ssd1306_SetCursor(0, 20);
        ssd1306_WriteString(line, Font_7x10, White);
        ssd1306_UpdateScreen();
    } else {
        ssd1306_Fill(Black);
        ssd1306_SetCursor(0, 0);
        ssd1306_WriteString("REG0A OKUNAMADI", Font_7x10, White);
        ssd1306_UpdateScreen();
    }
}


uint16_t Read_ADC_Value(void)
{
    HAL_ADC_Start(&hadc);
    HAL_ADC_PollForConversion(&hadc, 100);
    uint16_t val = HAL_ADC_GetValue(&hadc);
    HAL_ADC_Stop(&hadc);
    return val;
}
static void Read_ADC_Both(uint16_t* ch0, uint16_t* ch1)
{
    HAL_ADC_Start(&hadc);
    // 1. dönüş: IN0 (PA0)
    HAL_ADC_PollForConversion(&hadc, 100);
    *ch0 = HAL_ADC_GetValue(&hadc);
    // 2. dönüş: IN1 (PA1)
    HAL_ADC_PollForConversion(&hadc, 100);
    *ch1 = HAL_ADC_GetValue(&hadc);
    HAL_ADC_Stop(&hadc);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_ADC_Init();
    MX_USART2_UART_Init();

    ssd1306_Init();
    ssd1306_Fill(Black);
    ssd1306_UpdateScreen();
    HAL_Delay(200);

    RDA_Init();
    RDA_SetBand(0);
    RDA_SetSpace(0);
    RDA_SetMute(FALSE);
    HAL_Delay(300);

    uint16_t adc0 = 0, adc1 = 0;
    uint16_t lastFreqRaw = 0;
    uint8_t  lastVol     = 0xFF;

    while (1)
    {
        // ==== ADC oku ====
        Read_ADC_Both(&adc0, &adc1);
        // Seri monitöre bas
        {
            char uartBuf[64];
            int len = sprintf(uartBuf, "ADC0=%u, ADC1=%u\r\n", adc0, adc1);
            HAL_UART_Transmit(&huart2, (uint8_t*)uartBuf, len, HAL_MAX_DELAY);
        }

        // ==== Map => frekans ve ses ====
        // 0–4095 → 875–1080 arası (87.5–108.0 MHz *10)
        uint16_t freqRaw = 875 + ((adc0 * (1080-875)) / 4095);
        uint8_t  vol     = (adc1 * 15) / 4095;

        // ==== Değiştiyse RDA5807'ye uygula ====
        if (freqRaw != lastFreqRaw) {
            RDA_Tune(freqRaw);
            lastFreqRaw = freqRaw;
        }
        if (vol != lastVol) {
            RDA_SetVolume(vol);
            lastVol = vol;
        }

        // ==== Kalite bilgisi al ====
        getStatus(REG0A);
        getStatus(REG0B);
        int     rssi   = RDA_GetQuality();
        uint8_t fmTrue = handle.reg0B.refined.FM_TRUE;

        // ==== Ekranı güncelle ====
        ssd1306_Fill(Black);
        char line[32];

        sprintf(line, "F:%d.%dMHz", lastFreqRaw/10, lastFreqRaw%10);
        ssd1306_SetCursor(0,  0);
        ssd1306_WriteString(line, Font_7x10, White);

        sprintf(line, "Vol:%d", lastVol);
        ssd1306_SetCursor(0, 10);
        ssd1306_WriteString(line, Font_7x10, White);

        sprintf(line, "RSSI:%d", rssi);
        ssd1306_Setcursor(0, 20);
        ssd1306_WriteString(line, Font_7x10, White);

        sprintf(line, "FM:%d", fmTrue);
        ssd1306_SetCursor(0, 30);
        ssd1306_WriteString(line, Font_7x10, White);

        ssd1306_UpdateScreen();

        HAL_Delay(200);
    }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_5;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc.Instance = ADC1;
  hadc.Init.OversamplingMode = DISABLE;
  hadc.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ContinuousConvMode = ENABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerFrequencyMode = ENABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_2;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00000608;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
